.. _compareAss:

============================
Part 5: metaT-only assembly?
============================

Compare the contigs from a metaT-only assembly to a MAG...

