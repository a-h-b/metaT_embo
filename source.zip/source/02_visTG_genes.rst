.. _visTG_genes:

===========================================
Part 2: Compare metaT & metaG at gene level
===========================================


