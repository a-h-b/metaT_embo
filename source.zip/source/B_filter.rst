.. _rule-filter:

===================
Filtering
===================


