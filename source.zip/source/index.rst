.. metaT documentation master file, created by
   sphinx-quickstart on Sun Apr 24 05:58:21 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to the metaT hands-on!
==============================

.. toctree::
   :maxdepth: 2
   :hidden:
   :caption: Sections:
   :name: contents

   01_FC.rst
   02_visTG_genes.rst
   03_visKO.rst
   04_extractBin.rst
   05_compareMetaTass.rst
   06_visIGV.rst
   07_geneTypeOverTime.rst
   08_visPathway.rst

.. toctree::
   :maxdepth: 1
   :hidden:
   :caption: Processing steps:
   :name: processing

   A_trim.rst
   B_filter.rst
   C_assembly.rst
   D_mapping.rst
   E_annotation.rst
   G_featureCount.rst
   H_binExtract.rst

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
